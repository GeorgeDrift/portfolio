
import React from 'react';
import ProfileManager from './ProfileManager';
import ProjectsManager from './ProjectsManager';
import GalleryManager from './GalleryManager';

interface DashboardProps {
  token: string;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ token, onLogout }) => {
  return (
    <div>
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-900">Portfolio Admin Dashboard</h1>
          <button
            onClick={onLogout}
            className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700"
          >
            Logout
          </button>
        </div>
      </header>
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="space-y-8">
            <ProfileManager token={token} />
            <ProjectsManager token={token} />
            <GalleryManager token={token} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
